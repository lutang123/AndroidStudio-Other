import 'package:flutter/material.dart';

import '../helpers/style.dart';


class SmallButton extends StatelessWidget {
  final IconData icon;

  SmallButton(this.icon);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
      ),
    );
  }
}
